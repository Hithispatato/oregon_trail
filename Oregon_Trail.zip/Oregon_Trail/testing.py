import datetime
time = datetime.date(2009, 1, 6)
time2 = datetime.date((2009, 1, 6))
print(time)
print(time2)