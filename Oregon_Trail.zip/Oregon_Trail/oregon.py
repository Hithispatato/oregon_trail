# Oregon Trail
# By Ocra004, LJCoder619, Shadowfax13, ripsticker123, and others. 
import os #For animation
import random #For chance
import time #For waiting
import datetime #Dates 
import pickle #Game data dump!
import sys #For exiting!
# Classes
class Users:
    def __init__(self, namelist, role, health, oxen, food, ammo, clothes, parts, money, y, m, d):
        self.namelist = namelist # Defining
        self.nameone = namelist[0]
        self.nametwo = namelist[1]
        self.namethree = namelist[2]
        self.namefour = namelist[3]
        self.namefive = namelist[4]
        self.healthlist = health
        self.healthone = health[0]
        self.healthtwo = health[1]
        self.healththree = health[2]
        self.healthfour = health[3]
        self.healthfive = health[4]
        self.role = role
        self.oxen = oxen
        self.food = food
        self.ammo = ammo
        self.clothes = clothes
        self.axle = 0
        self.tongue = 0
        self.wheel = 0
        self.parts = {self.axle: parts[0], self.wheel: parts[1], self.tongue: parts[2]}
        self.milesToGo = 2000
        self.supplies = {'money': money, 'oxen': oxen, 'food': food, 'ammo': ammo, \
                         'clothes': clothes, 'parts': parts}
        self.running = True
        self.sicknesses = ['no', 'no', 'no', 'no', 'no', 'no', 'dysentery', 'cholera', 'exhaustion', 'rickets', 'a broken leg', 'a broken arm']
        self.deadusers = []
        self.date = datetime.date(y, m, d)
    def theftCalc(self):
        answer = ""
        if money >= 1000:
            rint = random.randint(1, 5)
            if rint == 1:
                answer = "$100 was stolen."
        elif (money > 500) and (money < 1000):
            rint = random.randint(1, 7)
            if rint == 1:
                answer = "$75 was stolen."
        else:
            rint = random.randint(1, 10)
            if rint == 1:
                answer = "$50 was stolen."
        self.answer = answer

    def supplyupdate(self, newMoney, newOxen, newFood, newAmmo, newClothes, newParts):
        self.supplies = {'money': money, 'oxen': oxen, 'food': food, 'ammo': ammo, \
                         'clothes': clothes, 'parts': parts}
    def illness(self):
        self.sickuser = random.choice(self.namelist)
        self.sickness = random.choice(self.sicknesses)
        if self.sickness != 'no':
            return str(self.sickuser) + 'has' + str(self.sickness)
        else:
            return None
    def dead(self):
        var = random.randint(1, 40)
        if var == 40:
            self.deaduser = random.choice(self.namelist)
            self.deadusers.append(self.deaduser)
            self.namelist.remove(self.deaduser)
        else:
            return None
    def rest(self, days):
        d = datetime.timedelta(days)
        self.date += d
    
    def hunt(self):
        animal = input("Which animal would you like to hunt(bear, rabbit, weasel, squirrel, deer)?")
        if animal == "bear":
            print("From the animals you hunted, you got " + str(200) + " pounds of food.")
            self.food += 200
        elif animal == "rabbit":
            print("From the animals you hunted, you got " + str(30) + " pounds of food.")
            self.food += 30
        elif animal == "weasel":
            print("From the animals you hunted, you got " + str(50) + " pounds of food.")
            self.food += 50
        elif animal == "squirrel":
            print("From the animals you hunted, you got " + str(15) + " pounds of food.")
            self.food += 15
        elif animal == "deer":
            self.food += 100
    
    def run(self):
        while self.running == True:
            self.food += -10
class Cart:
    def __init__(self, oxen, food, ammo, clothes, parts, userList, imgFiles, month):
        self.parts = parts
        self.axle = parts[0]
        self.wheel = parts[1]
        self.tongue = parts[2]
        self.oxen = oxen
        self.food = food
        self.ammo = ammo
        self.clothes = clothes
        self.food = food
        self.images = []
        self.imgFiles = imgFiles
        self.month = month
        self.months = ['April', 'May', 'June', 'July', 'August']
        self.coldweathers = ['very cold', 'cold', 'cool']
        self.hotweathers = ['warm', 'hot', 'very hot']
        self.rainweathers = ['rainy', 'very rainy']
        self.allweathers = self.coldweathers + self.hotweathers + self.rainweathers
        for name in imgFiles:
            with open(name, 'r', encoding='utf8') as fl:
                self.images.append(fl.readlines())

        self.running = True
    def cartFailiure(self):
        axle = random.randint(1, 50)
        wheel = random.randint(1, 75)
        tongue = random.randint(1, 100)
        if axle == 50:
            self.running = False
            return 'Broken Wagon axle'
        if wheel == 75:
            self.running = False
            return 'Broken Wagon wheel'
        if tongue == 100:
            self.running = False
            return 'Broken Wagon tongue'

    def animate(self):
        counter = 0
        while self.running == True :
            print(''.join(self.images[counter]))
            time.sleep(1)
            os.system('cls')
            if 0 <= counter < 1:
                counter+=1
            else:
                counter = 0
    
    def cartsick(self):
        if self.month == 'June':
            a = random.randint(0, 10)
            if a == 10:
                return "Inadequate Grass :("
    

class River:
    def __init__(self, length, name, depth, forded, caulked, running, imglist, cart):
        #cart = [oxen, food, ammo, clothes, parts, userList]
        self.length = length
        self.name = name
        self.depth = depth
        self.forded = forded
        self.caulked = caulked
        self.running = running
        self.imglist = imglist
        self.oxen = cart[0]
        self.food = cart[1]
        self.ammo = cart[2]
        self.clothes = cart[3]
        self.parts = cart[4]
        self.userList = cart[5]
        self.images = []
        self.drowned = []
        for name in self.imglist:
            with open(name, 'r', encoding='utf8') as f2:
                self.images.append(f2.readlines())
    def animate(self):
        counter = 0
        while self.running == True:
            print(''.join(self.images[counter]))
            time.sleep(1)
            os.system('cls')
            if 0 <= counter < 4:
                counter+=1
            else:
                counter = 0
    def drown(self):
        if self.depth > 300:
            self.ammo += -100
            self.oxen +=-3
            self.parts[0] += -2
            self.parts[1] += -2
            self.parts[2] +=-2
            drown = random.choice(self.userList)
            self.userList.remove(drown)

print("Welcome to the Oregon Trail!")
print("Would you like to 1 - Leave, or 2 - Play?")
leaveOrPlay = sys.stdin.readline()
if leaveOrPlay == "1\n":
    sys.exit()
elif leaveOrPlay == "2\n":
    named = False
    while named == False:
        print("Who is in your cart?")
        member1 = input("Member 1: ")
        member2 = input("Member 2: ")
        member3 = input("Member 3: ")
        member4 = input("Member 4: ")
        member5 = input("Member 5: ")
        namecorrect = input("Are these names correct? ")
        if namecorrect == 'y' or namecorrect == 'yes':
            named == True
            break
        else:
            named == False
    peoplehealth = [100, 100, 100, 100, 100]
    date = str(input('''Select the month you want to depart from Independence, Missouri
    1. March
    2. April
    3. May
    4. June
    5. July
    6. August'''))
    print("OK!")
    print("Select your role: ")
    print("1. Banker")
    print("2. Storekeeper")
    print("3. Worker at a factory")
    print("4. Carpenter")
    print("5. Silversmith")
    choice = input("Role(number): ")
    if choice == '1':
        print("Good Choice! You have $6000 in cash.")
        money = 6000
    elif choice == '2':
        print("Nice, you have $5000 in cash.")
        money = 5000
    elif choice == '3':
        print("Ok! You have $4000 in cash.")
        money = 4000
    elif choice == '4':
        print("Sure! You have $3500 in cash.")
        money = 3500
    elif choice == '5':
        print("Crafty! You have $5000 in cash.")
        money = 5000
    else:
        sys.exit()
    print("Let's go to the shop to buy supplies!")
    print('''               
            ,:' `..;
            `. ,;;'%
            +;;'%%%%%
             /- %,)%%
             ` / \ %%
              =  )/ \\
              `-'/ / \\
                /\/.-.\\
               |  (    |
               |  |   ||     Welcome To Bob's hardware store! So, you're going to Oregon, right? 
               |  |   ||             I'll fix some supplies up for you with how much money you have!
               |  |   ||
           _.-----'   ||
          / \________,'|
         (((/  |       |
         //    |       |
        //     |\      |
       //      | \     |
      //       |  \    |
     //        |   \   |
    //         |    \  |
   //          |    |\ |
  //           |    | \|
 //            \    \\
c'             |\    \\
               | \    \\
               |  \    \\
               |.' \    \\
              _\    \.-' \ 
             (___.-(__.'\/)''')
    time.sleep(2)
    shop = True
    oxen = 0
    food = 0
    ammo = 0
    clothes = 0
    parts = 0
    while shop:
        oxen_choice = True
        food_choice = True
        ammo_choice = True
        clothes_choice = True
        parts_choice = True
        print("Welcome to Bob's Hardware shop! Select what you want to buy.")
        time.sleep(1)
        print("1.Yokes of oxen (150 dollars each)")
        print("2.Food (1 dollar per pound)")
        print("3.Ammunition (2 dollars per box)")
        print("4.Clothing (5 dollars per set)")
        print("5.Spare Parts (10 dollars each)")
        print('Enter "." to leave.')
        print('You have', money, "to spend")
        print('You have', oxen*2, "oxen")
        print("You have", food, "pounds of food")
        print("You have", ammo, "boxes of ammo")
        print("You have", clothes, "sets of clothes")
        print("You have", parts, "spare parts")
        shop_choice = input("What is your choice?: ")

        if shop_choice == ".":
            shop = False
        elif shop_choice == "1":
            while oxen_choice:
                oxen = int(input("How many yokes(pairs) would you like to buy? "))
                if oxen < 0:
                    print("Please purchase a positive integer.")
                elif (oxen * 150) > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} oxen.".format(oxen))
                    money = money - (oxen * 150)
                    oxen_choice = False

        elif shop_choice == "2":
            while food_choice:
                food = int(input("How many pounds of food would you like to buy? "))
                if food < 0:
                    print("Please purchase a positive integer.")
                elif food > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} pounds of food.".format(food))
                    money = money - food
                    food_choice = False

        elif shop_choice == "3":
            while ammo_choice:
                ammo = int(input("How many boxes of ammunition would you like to buy? "))
                if ammo < 0:
                    print("Please purchase a positive integer.")
                elif (ammo * 2) > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} boxes of ammo.".format(ammo))
                    money = money - (ammo * 2)
                    ammo_choice = False

        elif shop_choice == "4":
            while clothes_choice:
                clothes = int(input("How many sets of cloths would you like to buy? "))
                if clothes < 0:
                    print("Please purchase a positive integer.")
                elif (clothes * 5) > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} sets of clothes.".format(clothes))
                    money = money - (clothes * 5)
                    clothes_choice = False

        elif shop_choice == "5":
            while parts_choice:
                parts = []
                axles =  int(input("How many spare axles would you like to buy?(3 max) "))
                parts.append(axles)
                if axles < 0 or axles > 3:
                    print("Please purchase a positive integer or valid number.")
                elif (axles * 10) > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} spare axles.".format(axles))
                    money = money - (axles * 10)
                wheels =  int(input("How many spare wheels would you like to buy?(3 max) "))
                parts.append(wheels)
                if wheels < 0 or wheels > 3:
                    print("Please purchase a positive integer or valid number.")
                elif (wheels * 10) > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} spare wheels.".format(wheels))
                    money = money - (wheels * 10)
                tongues =  int(input("How many spare wagon tongues would you like to buy?(3 max) "))
                parts.append(tongues) 
                if  tongues < 0 or tongues > 3:
                    print("Please purchase a positive integer or valid number.")
                elif (tongues * 10) > money:
                    print("You do not have enough money.")
                else:
                    print("You purchased {} spare tongues.".format(tongues))
                    money = money - (tongues * 10)
                    print(parts)
                    parts_choice = False                
                

        else:
            sys.exit()
    if date == "1":
        y = 1854
        m = 3
        d = 1
    elif date == "2":
        y = 1854
        m = 4
        d = 1
    elif date == "3":
        y = 1854
        m = 5
        d = 1
    elif date == "4":
        y = 1854
        m = 6
        d = 1
    elif date == "5":
        y = 1854
        m = 7
        d = 1
    elif date == "6":
        y = 1854
        m = 8
        d = 1

    users = Users([member1, member2, member3, member4, member5], choice, peoplehealth, oxen, food, ammo, clothes, parts, money, y, m, d)
